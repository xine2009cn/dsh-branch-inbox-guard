# dsh-branch-inbox-guard

修复 DSH 0.1.5 的分支会话缺陷：**fork 出来的子会话会继承父会话未投递的排队提问**，
导致在分支里新输入的问题被排到队尾、分支先去执行"主干分支点之后的下一个问题"。

完整背景、证据与版本考古见上级目录的 `README.md`（尤其 §7：这是 0.1.1-rc.2 → 0.1.5 的回归，
旧版 `Inbox` 用 `session.events.slice(header.seedLength)` 跳过继承前缀，0.1.5 的 inbox 投影折叠全量日志）。

## 它做什么

在每次 `agent/created` 时，删除**插入位置落在本会话继承切点（`inheritedEventCount`）之前**的待执行项：

| 场景 | 行为 |
|---|---|
| 刚 fork 出来的子会话 | 继承来的父会话提问全部清掉（等价于 0.1.1 的可见行为） |
| 已被污染、之后又排了自己消息的会话 | 只清继承项，**保留会话自己排的队**（顺带治好历史遗留脏队列） |
| 普通新会话 / 未 seed 的会话 | 完全不动（cut=0 直接返回） |
| fork 型 subagent | 同样生效（子代理的任务不会被父会话排队项插队） |

删除是**持久化**的（追加 `agent/inbox/spliced` 取消事件），重启后队列依然干净；重复触发幂等。
不修改任何核心包，不动会话历史，不改变 `resume` 时会话自己排的队。

## 安装（本机容器 rootfs 只读，这条路径不需要 root）

```bash
FIX=/data/dsh/home/proj_geek/20260911e-session-branch_修复
bash $FIX/install-plugin.sh            # 打 tarball 到 $DSH_HOME/vendor 并用 dsh plugin add 安装
docker restart <dsh 容器名>            # 或 1Panel 里重启应用
```

安装脚本会：`npm pack` 出 `$DSH_HOME/vendor/dsh-branch-inbox-guard-0.1.0.tgz` →
`dsh plugin --profile web add file:...` → 核对 profile 的 `package.json`/`node_modules`。
（`dsh plugin` 需要写 `/data/dsh/profiles/web`，请在**非沙箱视图**执行：1Panel 终端或
`docker exec -u 1000:1000 <容器> bash ...`。）

## 卸载 / 回滚

```bash
dsh plugin --profile web remove dsh-branch-inbox-guard
docker restart <dsh 容器名>
```

## 自检

```bash
node /data/dsh/home/proj_geek/20260911e-session-branch_修复/test/branch-guard-plugin.test.mjs
```

离线测试用真实 `Session` / `ReactLoopInbox` / 真实 fork 源日志驱动守卫逻辑：
纯 fork 子会话（清 5 条）、"继承 5 条 + 自有 1 条"（只清继承、保留自有）、
未 seed 会话（不动）、重复触发（幂等）。

运行日志里能看到：

```
[branch-inbox-guard] session-xxxx: dropped 5 inherited prompt(s) from its fork parent
```

## 兼容性

针对 DSH 0.1.5-rc.1 / 0.1.5-rc.2 验证（`agent/created` 事件、`agent.inbox.clear/remove`、
`session.inheritedEventCount` 均为公开接口）。DSH 升级后建议重跑一次自检；
若上游修复了该回归（例如 inbox 投影重新尊重 `inheritedEventCount`），本插件可直接卸载。
